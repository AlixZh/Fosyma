package eu.su.mas.dedaleEtu.mas.behaviours;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import dataStructures.tuple.Couple;
import eu.su.mas.dedale.env.Observation;
import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedaleEtu.mas.agents.dummies.explo.ExploreCoopAgent;
import eu.su.mas.dedaleEtu.mas.knowledge.SMEnd;
import eu.su.mas.dedaleEtu.mas.knowledge.SMPosition;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class SendBlockBehaviour extends OneShotBehaviour{
	private static final long serialVersionUID = 8802075205635695208L;
	private boolean finished= false;
	private List<String> CgChasse;
	
	// Send to other agent that it finished
	public SendBlockBehaviour(final Agent myagent,List<String> CgChasse) {
		super(myagent);
		this.CgChasse=CgChasse;
	}
	
	@Override
	public void action() {
		//1) receive messages
		final ACLMessage msg2 = new ACLMessage(ACLMessage.INFORM);
		msg2.setProtocol("ADD_ME_AS_BLOCK");
		//2) Set the sender and the receiver(s)
		msg2.setSender(this.myAgent.getAID());
		for(String s:((ExploreCoopAgent) this.myAgent).getAgentsListDF("coureur")) {
			if(s==this.myAgent.getLocalName()|| CgChasse.contains(s)) continue;
			msg2.addReceiver(new AID(s,AID.ISLOCALNAME));
		}
		try {
			msg2.setContentObject(new SMEnd(((ExploreCoopAgent) this.myAgent).getfiniblock()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3) send the message
		((AbstractDedaleAgent)  this.myAgent).sendMessage(msg2);
	}
}
