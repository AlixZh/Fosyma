package eu.su.mas.dedaleEtu.mas.behaviours;




import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import dataStructures.tuple.Couple;
import eu.su.mas.dedale.env.Observation;
import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedaleEtu.mas.agents.dummies.explo.ExploreCoopAgent;
import eu.su.mas.dedaleEtu.mas.knowledge.MapRepresentation;
import eu.su.mas.dedaleEtu.mas.knowledge.SMPosition;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class SendDecisionBehaviour extends OneShotBehaviour{
	private static final long serialVersionUID = 8802075205635695208L;
	private HashMap<String,List<String>> myStench;
	private HashMap<String,String>agents_pos;
	private Couple<Date,HashMap<String,String>>decision_nextmove;
	public SendDecisionBehaviour(final Agent myagent,HashMap<String,List<String>>stench,HashMap<String,String>agents_pos) {
		super(myagent);
		this.myStench=stench;
		this.agents_pos=agents_pos;
		
	}
	
	@Override
	public void action() {
		//eliminer pos stench impossible etre position wumpus
		//intersection de nodes adjacents des stenchs possible pour predire la position wumpus
		List<String>list_stench=new ArrayList<String>();
		
	}




}
